/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

/**
 *
 * @author Brayan
 */
public class notaIdeal {
     double nota;

    public notaIdeal(double nota) {
        this.nota = nota;
    }
}
