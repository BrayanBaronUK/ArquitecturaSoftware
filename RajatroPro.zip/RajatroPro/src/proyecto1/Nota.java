/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

/**
 *
 * @author Brayan
 */
public class Nota {

    String nombreCriterio;
    double valor;

    public Nota(String nombreCriterio, double valor) {
        this.nombreCriterio = nombreCriterio;
        this.valor = valor;
    }

}
